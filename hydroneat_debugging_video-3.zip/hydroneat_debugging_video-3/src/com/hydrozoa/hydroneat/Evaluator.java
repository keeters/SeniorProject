package com.hydrozoa.hydroneat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.nlogo.agent.TreeAgentSet;
import org.nlogo.headless.HeadlessWorkspace;
import com.hydrozoa.hydroneat.test.IntegerList;

public abstract class Evaluator {
	
	private FitnessGenomeComparator fitComp = new FitnessGenomeComparator();
	
	private Counter nodeInnovation;
	private Counter connectionInnovation;
	
	private Random random = new Random();
	
	private NEATConfiguration configuration;
	
	private List<Genome> genomes;
	private List<FitnessGenome> fitnessGenomes;
	private List<Genome> nextGenGenomes;
	
	private List<Species> species;
	
	private Map<Genome, Species> mappedSpecies;
	private Map<Genome, Float> scoreMap;
	private float highestScore;
	private int stagnation = 0;
	private Genome fittestGenome;
		
	private HeadlessWorkspace workspace;
	
	public Evaluator(NEATConfiguration configuration, Genome startingGenome, Counter nodeInnovation, Counter connectionInnovation) {
		this.configuration = configuration;
		this.nodeInnovation = nodeInnovation;
		this.connectionInnovation = connectionInnovation;
		
		genomes = new ArrayList<Genome>(configuration.getPopulationSize());
		for (int i = 0; i < configuration.getPopulationSize(); i++) {
			genomes.add(new Genome(startingGenome));
		}
		species = new ArrayList<Species>();
	}
	
	public void setWorkspace(HeadlessWorkspace workspace){/////////////////////////////////////////////////////////
		this.workspace = workspace;
	}//////////////////////////////////////
	
	
	/**
	 * Runs one generation
	 */
	public void evaluate() {
		stagnation++;
		
		// Reset everything for next generation
		for (Species s : species) {
			s.reset(random);
		}
		scoreMap = new HashMap<Genome, Float>();
		mappedSpecies = new HashMap<Genome, Species>();
		nextGenGenomes = new LinkedList<Genome>();
		fitnessGenomes = new LinkedList<FitnessGenome>();
		
		// Place genomes into species
		int added = 0;


		for (Genome g : genomes) {
			boolean foundSpecies = false;
			int count = 0;

			for (Species s : species) {
				count +=1;
				if (Genome.compatibilityDistance(g, s.mascot, configuration.C1, configuration.C2, configuration.C3) < configuration.DT) { // compatibility distance is less than DT, so genome belongs to this species
					s.members.add(g);
					mappedSpecies.put(g, s);
					foundSpecies = true;
					break;
				}
			}
			if (!foundSpecies) { // if there is no appropiate species for genome, make a new one
				Species newSpecies = new Species(g);
				species.add(newSpecies);
				mappedSpecies.put(g, newSpecies);
				added++;
			}
		}
		//System.out.println("Added "+added+" species");
		
		// Remove unused species
		removeEmptySpecies();
		
		// Evaluate genomes and assign score
		for (Genome g : genomes) {
			Species s = mappedSpecies.get(g);		// Get species of the genome
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			float score = evaluateGenome(g); ////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			float adjustedScore = score / mappedSpecies.get(g).members.size();
			
			FitnessGenome fitGenome = new FitnessGenome(g, adjustedScore);
			
			s.addAdjustedFitness(adjustedScore);	
			s.fitnessPop.add(fitGenome);
			
			fitnessGenomes.add(fitGenome);
			
			scoreMap.put(g, adjustedScore);
			if (score > highestScore) {
				stagnation = 0;
				highestScore = score;
				fittestGenome = g;
			}
		}
		
		// put best genomes from each species into next generation
		nextGenGenomes.add(fittestGenome);
		for (Species s : species) {
			if (s.members.size() > 5) {
				Collections.sort(s.fitnessPop, fitComp);
				Collections.reverse(s.fitnessPop);
				FitnessGenome fittestInSpecies = s.fitnessPop.get(0);
				//System.out.println("Adding genome with fitness: "+fittestInSpecies.fitness);
				nextGenGenomes.add(fittestInSpecies.genome);
			}
		}
		
		if (stagnation > 40) {
			System.out.println("CLEANING UPUUUP!");
			Collections.sort(fitnessGenomes, fitComp);
			Collections.reverse(fitnessGenomes);
			for (int i = 5; i < fitnessGenomes.size(); i++) {
				FitnessGenome fg = fitnessGenomes.get(i);
				genomes.remove(fg.genome);
				for (Species s : species) {
					s.members.remove(fg.genome);
					s.fitnessPop.remove(fg);
					mappedSpecies.remove(fg.genome);
					scoreMap.remove(fg.genome);
				}
			}
			removeEmptySpecies();
			stagnation = 0;
		}
		
		// Breed the rest of the genomes
		while (nextGenGenomes.size() < configuration.getPopulationSize()) { // replace removed genomes by randomly breeding
			Species s = getRandomSpeciesBiasedAjdustedFitness(random);
			
			Genome p1 = getRandomGenomeBiasedAdjustedFitness(s, random);
			Genome p2 = getRandomGenomeBiasedAdjustedFitness(s, random);
			
			if (random.nextFloat() < 0.2f) {
				if (scoreMap.get(p1) >= scoreMap.get(p2)) {
					Genome mutated = new Genome(p1);
					mutated.mutation(random);
					nextGenGenomes.add(mutated);
				} else {
					Genome mutated = new Genome(p2);
					mutated.mutation(random);
					nextGenGenomes.add(mutated);
				}
			} else {
				Genome child;
				if (scoreMap.get(p1) >= scoreMap.get(p2)) {
					child = Genome.crossover(p1, p2, random);
				} else {
					child = Genome.crossover(p2, p1, random);
				}
				if (random.nextFloat() < configuration.MUTATION_RATE) {
					child.mutation(random);
				}
				if (random.nextFloat() < configuration.ADD_CONNECTION_RATE) {
					//System.out.println("Adding connection mutation...");
					child.addConnectionMutation(random, connectionInnovation, 10);
				}
				if (random.nextFloat() < configuration.ADD_NODE_RATE) {
					//System.out.println("Adding node mutation...");
					child.addNodeMutation(random, connectionInnovation, nodeInnovation);
				}
				nextGenGenomes.add(child);
			}
		}
		
		genomes = nextGenGenomes;
		nextGenGenomes = new ArrayList<Genome>();
	}
	
	private void removeEmptySpecies() {
		Iterator<Species> iter = species.iterator();
		while(iter.hasNext()) {
			Species s = iter.next();
			if (s.members.isEmpty()) {
				iter.remove();
			}
		}
	}
	
	/**
	 * Selects a random species from the species list, where species with a higher total adjusted fitness have a higher chance of being selected
	 */
	private Species getRandomSpeciesBiasedAjdustedFitness(Random random) {
		double completeWeight = 0.0;	// sum of probablities of selecting each species - selection is more probable for species with higher fitness
		for (Species s : species) {
            completeWeight += s.totalAdjustedFitness;
		}
        double r = Math.random() * completeWeight;
        double countWeight = 0.0;
        for (Species s : species) {
            countWeight += s.totalAdjustedFitness;
            if (countWeight >= r) {
            	 return s;
            }
        }
        throw new RuntimeException("Couldn't find a species... Number is species in total is "+species.size()+", and the total adjusted fitness is "+completeWeight);
	}
	
	/**
	 * Selects a random genome from the species chosen, where genomes with a higher adjusted fitness have a higher chance of being selected
	 */
	private Genome getRandomGenomeBiasedAdjustedFitness(Species selectFrom, Random random) {
		double completeWeight = 0.0;	// sum of probablities of selecting each genome - selection is more probable for genomes with higher fitness
		for (FitnessGenome fg : selectFrom.fitnessPop) {
			completeWeight += fg.fitness;
		}
        double r = Math.random() * completeWeight;
        double countWeight = 0.0;
        for (FitnessGenome fg : selectFrom.fitnessPop) {
            countWeight += fg.fitness;
            if (countWeight >= r) {
            	 return fg.genome;
            }
        }
        throw new RuntimeException("Couldn't find a genome... Number is genomes in selected species is "+selectFrom.fitnessPop.size()+", and the total adjusted fitness is "+completeWeight);
	}
	
	public int getSpeciesAmount() {
		return species.size();
	}
	
	public float getHighestFitness() {
		return highestScore;
	}
	
	public Genome getFittestGenome() {
		return fittestGenome;
	}
	
	protected abstract float evaluateGenome(Genome genome);
	
	public class FitnessGenome {
		
		float fitness;
		Genome genome;
		
		public FitnessGenome(Genome genome, float fitness) {
			this.genome = genome;
			this.fitness = fitness;
		}
	}
	
	public class Species {
		
		public Genome mascot;
		public List<Genome> members;
		public List<FitnessGenome> fitnessPop;
		public float totalAdjustedFitness = 0f;
		
		public Species(Genome mascot) {
			this.mascot = mascot;
			this.members = new LinkedList<Genome>(); 
			this.members.add(mascot);
			this.fitnessPop = new ArrayList<FitnessGenome>(); 
		}
		
		public void addAdjustedFitness(float adjustedFitness) {
			this.totalAdjustedFitness += adjustedFitness;
		}
		
		/*
		 *	 Selects new random mascot + clear members + set totaladjustedfitness to 0f
		 */
		public void reset(Random r) {
			int newMascotIndex = r.nextInt(members.size());
			this.mascot = members.get(newMascotIndex);
			members = new LinkedList<Genome>();
			fitnessPop = new LinkedList<FitnessGenome>();
			totalAdjustedFitness = 0f;
		}
	}
	
	public class FitnessGenomeComparator implements Comparator<FitnessGenome> {

		@Override
		public int compare(FitnessGenome one, FitnessGenome two) {
			if (one.fitness > two.fitness) {
				return 1;
			} else if (one.fitness < two.fitness) {
				return -1;
			}
			return 0;
		}
		
	}

    public static float[] gatherInputs(HeadlessWorkspace workspace){
    	//change as needed
    	int maxX = 17;
    	int maxY = 13;
    	
    	float[][] testArray = new float[maxY][maxX];
    	Integer triangleCount = ((Double) workspace.report("count triangles")).intValue();
    	Integer circleCount = ((Double) workspace.report("count circles")).intValue();
    	Integer squareCount = ((Double) workspace.report("count squares")).intValue();
    	Integer turtleCount = ((Double) workspace.report("count turtles")).intValue();
    	System.out.println("TurtleCount: " + turtleCount.toString());
    	Integer i = 2; //first 2 turtles are players
    	for(i=2; i<turtleCount; i++){
    		//System.out.println(workspace.report("[team] of turtle "+i.toString()));
    		boolean alive = (boolean) workspace.report("is-turtle?(turtle "+i.toString()+")");
    		if(alive){
    		TreeAgentSet breedItem = (TreeAgentSet) workspace.report("[breed] of turtle "+i.toString());
    		String breed = breedItem.printName();
    		int xcore = ((Double) workspace.report("[xcor] of turtle "+i.toString())).intValue();
    		int ycore = ((Double) workspace.report("[ycor] of turtle "+i.toString())).intValue();
    		xcore = xcoreConverter(xcore);
    		ycore = ycoreConverter(ycore);
    		String team = (String) workspace.report("[team] of turtle "+i.toString());


	       		 if(breed.equals("TRIANGLES")){

			   		 if (team.equals("opponent") ){
			   			 System.out.println("made a triangle");
			   			 testArray[ycore][xcore] = -2;
			   		 }else{
			   			 testArray[ycore][xcore] = 2;
			   		 }
		    		}
	       		 
	       		if(breed.equals("CIRCLES")){
	    	       	
			   		 if (team.equals("opponent") ){
			   			 testArray[ycore][xcore] = -2;
			   		 }else{
			   			 testArray[ycore][xcore] = 2;
			   		 }
		    		}
	       		 
	       		if(breed.equals("SQUARES")){
			   		 if (team.equals("opponent") ){
			   			 testArray[ycore][xcore] = -3;
			   		 }else{
			   			 testArray[ycore][xcore] = 3;
			   		 }
		    	}
    		}
		    
//    	}
//    	for(i=0; i<triangleCount; i++){
//    		System.out.println(triangleCount);
//    		 int xcore = (int) workspace.report(" xcor of triangle "+triangleCount.toString());
//    		 int ycore = (int) workspace.report(" ycor of triangle "+triangleCount.toString());
//    		 Object team =  workspace.report(" team of turtle "+triangleCount.toString());
//    		 if (testArray[ycore][xcore] != 0){ //if something else in space
//    			 if ((testArray[ycore][xcore]*testArray[ycore][xcore]) != 1){ //if its not 2 triangles
//        			 System.out.println("something in space problem");
//        		 }else{ //if it is 2 triangles
//        			 testArray[ycore][xcore] = 0;
//        		 }
//    		 } else{
//    		 if (team =="oponent" ){
//    			 testArray[ycore][xcore] = -1;
//    		 }else{
//    			 testArray[ycore][xcore] = 1;
//    		 }
//    		 
//    	}
//    	}
//    	for(i=0; i<circleCount; i++){
//    		int xcore = (int) workspace.report(" xcor of circle "+i.toString());
//    		int ycore = (int) workspace.report(" ycor of circle "+i.toString());
//    		Object team =  workspace.report(" team of turtle "+triangleCount.toString());
//
//   		 if (testArray[ycore][xcore] != 0){ //if something else in space
//    			 System.out.println("something in space problem");
//    		 }
//		  else{
//		 if (team =="oponent" ){
//			 testArray[ycore][xcore] = -2;
//		 }else{
//			 testArray[ycore][xcore] = 2;
//		 }
//		 
//	}
//   }
//    	for(i=0; i<squareCount; i++){
//    		int xcore = (int) workspace.report(" xcor of square "+squareCount.toString());
//    		int ycore = (int) workspace.report(" ycor of square "+squareCount.toString());
//    		Object team =  workspace.report(" team of turtle "+triangleCount.toString());
//
//   		 if (testArray[ycore][xcore] != 0){ //if something else in space
//    			 System.out.println("something in space problem");
//		 } else{
//		 if (team =="oponent" ){
//			 testArray[ycore][xcore] = -3;
//		 }else{
//			 testArray[ycore][xcore] = 3;
//		 }
//		 
//	}
    	}
    	float[] finalArr = convertInputs(testArray);
    	float[] holder = finalArr.clone();
		Arrays.sort(holder);
		System.out.println("inputs in evaluator: "+ Float.toString(holder[0])+"\t"+Float.toString(holder[holder.length-1]));
		return finalArr;
    }
    private static int ycoreConverter(int ycore) {
		if(ycore == -8)
			return 0;
		if(ycore == -7){
			return 1;
		}
		if(ycore == -6){
			return 2;
		}		if(ycore == -5){
			return 3;
		}		if(ycore == -4){
			return 4;
		}		if(ycore == -3){
			return 5;
		}		if(ycore == -2){
			return 6;
		}		if(ycore == -1){
			return 7;
		}		if(ycore == 0){
			return 8;
		}		if(ycore == 1){
			return 9;
		}		if(ycore == 2){
			return 10;
		}		if(ycore == 3){
			return 11;
		}		if(ycore == 4){
			return 12;
		}		if(ycore == 5){
			return 13;
		}		if(ycore == 6){
			return 14;
		}		if(ycore == 7){
			return 15;
		}		else{
			return 16;
		}
	}

	private static int xcoreConverter(int xcore) {
		
		if(xcore == -6){
			return 2;
		}		if(xcore == -5){
			return 3;
		}		if(xcore == -4){
			return 4;
		}		if(xcore == -3){
			return 5;
		}		if(xcore == -2){
			return 6;
		}		if(xcore == -1){
			return 7;
		}		if(xcore == 0){
			return 8;
		}		if(xcore == 1){
			return 9;
		}		if(xcore == 2){
			return 10;
		}		if(xcore == 3){
			return 11;
		}		if(xcore == 4){
			return 12;
		}		if(xcore == 5){
			return 13;
		}		else{
			return 14;
		}		
	}

	public static float[] convertInputs(float[][] inputFLoat){
    	float[] finalFloat = new float[inputFLoat.length*inputFLoat[0].length];
    	int counter =0;
    	for(int i=0; i<inputFLoat.length; i++){
        	for(int j=0; j<inputFLoat[0].length; j++){
        		finalFloat[counter] =  inputFLoat[i][j];
        		counter +=1;
        	}
        }
    	return finalFloat;
    }
}
