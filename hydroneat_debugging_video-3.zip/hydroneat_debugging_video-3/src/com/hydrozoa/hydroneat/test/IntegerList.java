package com.hydrozoa.hydroneat.test;

import com.hydrozoa.hydroneat.ConnectionGene;
import com.hydrozoa.hydroneat.Counter;
import com.hydrozoa.hydroneat.Evaluator;
import com.hydrozoa.hydroneat.Genome;
import com.hydrozoa.hydroneat.NEATConfiguration;
import com.hydrozoa.hydroneat.NeuralNetwork;
import com.hydrozoa.hydroneat.NodeGene;
import com.hydrozoa.hydroneat.NodeGene.TYPE;

import org.nlogo.headless.HeadlessWorkspace;
import org.nlogo.app.App;
import java.awt.EventQueue;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.ThreadLocalRandom;
import java.lang.Double;
import java.text.DecimalFormat;

public class IntegerList {
	static Counter nodeInn = new Counter();
	static Counter connInn = new Counter();
	static Integer zeroCounter;
	public static org.nlogo.app.App app;
    public static void main(String[] argv) {
    	//note, model needs to be in project folder and properties->new jar-> Netlogo 6.04 Java 
        HeadlessWorkspace workspace = HeadlessWorkspace.newInstance();
        Double x = null;
        Double y = null;
    	Genome genome = initializeGenome(17, 13);
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(20);

		NEATConfiguration conf = new NEATConfiguration(10);
		conf.DT=10f;
		conf.ADD_NODE_RATE = 0.02f;
		conf.ADD_CONNECTION_RATE = 0.1f;
		
        Evaluator eval = new Evaluator(conf, genome, nodeInn, connInn) {
			@Override
			protected float evaluateGenome(Genome genome) {
		    	//figure out how to get workspace to eval. **FIXED** do this by calling setWorkspace 
		    	//This should be copied and pasted into the eval function.
		    	float fitness = 0f;
				NeuralNetwork net = new NeuralNetwork(genome);
				int gameOver = 0;
				long timePassed =0;
				long maxTimeAllowed=240000;
				long startTime = System.currentTimeMillis();
				workspace.command("setup");
				if(zeroCounter == null){
					zeroCounter = 0;
				}
				while(gameOver==0 && timePassed< maxTimeAllowed && zeroCounter<10){
					int i;
					i=0;
					for(i =0; i<200; i++){
						Double tick = (Double) workspace.report("ai-choice-tick");
						String tickStr = Double.toString(tick);
						if (tickStr.equals("200.0")){
							workspace.command("enemy-action");
						}
						
	            		workspace.command("run-game");
	            	}
					float[] input = gatherInputs(workspace);
					
					float[] outputs = new float[2];
					
					try {
						outputs = net.calculate(input);
					} catch (Exception e) {
						System.out.println("can't get outputs");
					}
					float[] holder = input.clone();
					Arrays.sort(holder);
					System.out.println("inputs: "+ Float.toString(holder[0])+"\t"+Float.toString(holder[holder.length-1]));
					System.out.println("outputs: "+ Float.toString(outputs[0])+"\t"+Float.toString(outputs[1]));
					
					moveMaker(workspace, genome, input);
					gameOver = winConditionCheck(workspace);
					timePassed = System.currentTimeMillis()-startTime;
				}
	    		zeroCounter=0;
	    		
				long totalTime = System.currentTimeMillis()-startTime;
		    	Double x = (Double) workspace.report("count patches with [pcolor = red]");
		        Double y = (Double) workspace.report("count patches with [pcolor = blue]");
		        Double z = (Double) workspace.report("count turtles");
		        Double patchesRemaining = y-x;
		        System.out.println("fitness: ");
		        if (patchesRemaining<0){
		        	System.out.println( (Float.toString( (float) (1+z/100) )));
		        	return (float) (1+(z/100));
		        }
		        
		        System.out.println((((16-patchesRemaining))*((100/totalTime)*gameOver)));
				return   (float) (((16-patchesRemaining))*((100/totalTime)*gameOver)+(z/10)+1);		
			}};
			
		
		
        try {
            workspace.open
                ("SeniorProject-master/"
                 + "Shapes of War.nlogo");
    		eval.setWorkspace(workspace);
            workspace.command("setup");
            
            boolean bool = true;
            
			for(int i =0; i<10; i++){
				eval.evaluate();
				System.out.print("Generation: "+i);
				System.out.print("\tHighest fitness: "+df.format(eval.getHighestFitness()));
				System.out.print("\tAmount of species: "+eval.getSpeciesAmount());
				//System.out.print("\tConnections in best performer: "+eval.getFittestGenome().getConnectionGenes().values().size());
				System.out.print("\tGuesses: ");        	
        	
                x = (Double) workspace.report("count patches with [pcolor = red]");
                y = (Double) workspace.report("count patches with [pcolor = blue]");

            }
            workspace.dispose();
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static float runEvaluator(Genome genome, HeadlessWorkspace workspace, Evaluator eval, int iterations){
		for (int i = 0; i < iterations; i++) {
			eval.evaluate();
			System.out.print("Generation: "+i);
			System.out.print("\tHighest fitness: "+eval.getHighestFitness());
			System.out.print("\tAmount of species: "+eval.getSpeciesAmount());
			System.out.print("\tConnections in best performer: "+eval.getFittestGenome().getConnectionGenes().values().size());
			System.out.print("\tGuesses: ");
		}
    	return 0;
    }
    
//    Added to evaluator
//    public static float fitnessRunner(Genome genome, HeadlessWorkspace workspace){
//    	float[] input = gatherInputs(workspace);
//    	//figure out how to get workspace to eval. **FIXED** do this by calling setWorkspace 
//    	//This should be copied and pasted into the eval function.
//    	float fitness = 0f;
//		NeuralNetwork net = new NeuralNetwork(genome);
//		int gameOver = 0;
//		long timePassed =0;
//		long maxTimeAllowed=240000;
//		long startTime = System.currentTimeMillis();
//		while(gameOver==0 && timePassed< maxTimeAllowed){
//			float[] outputs = new float[2];
//			
//			try {
//				outputs = net.calculate(input);
//			} catch (Exception e) {
//				System.out.println("can't get outputs");
//			}
//			
//			moveMaker(workspace, genome, input);
//			gameOver = winConditionCheck(workspace);
//			timePassed = System.currentTimeMillis()-startTime;
//		}
//		long totalTime = System.currentTimeMillis()-startTime;
//    	Double x = (Double) workspace.report("count patches with [pcolor = red]");
//        Double y = (Double) workspace.report("count patches with [pcolor = blue]");
//        Double patchesRemaining = x-y;
//		return   (float) (((16-patchesRemaining))*((100/totalTime)*gameOver));
//    }
    
    public static Genome initializeGenome(int x, int y){
    	Integer inputSize = x*y;
    	int outputSize = 7;
    	Genome genome = new Genome();
    	int i;
    	for(i=0; i<inputSize; i++){
    		genome.addNodeGene(new NodeGene(TYPE.INPUT, nodeInn.getInnovation()));
    	}
    	
    	for(i=0; i<outputSize; i++){
    		genome.addNodeGene(new NodeGene(TYPE.OUTPUT, nodeInn.getInnovation()));
    	}
    	for(i=0; i<inputSize; i++){
        	for(int j=0; j<outputSize; j++){
            	genome.addConnectionGene(new ConnectionGene(i,j,-1f,true, connInn.getInnovation()));

        	}
    	}
    	
    	return genome;
    	
    }
    
    public static Integer[] moveCalculator(Genome genome, float[] inputs){
    	NeuralNetwork net = new NeuralNetwork(genome);
    	

    	float[] control = net.calculate(inputs); //up down left right triangle circle square
    	
    	Integer move = 0;
    	Integer make = 0;
    	
    	if (control[0]>0 && !(control[1]>0) && !(control[2]>0) && !(control[3]>0)){
        	move = 1;
    	}else if (control[1]>0 && !(control[0]>0) && !(control[2]>0) && !(control[3]>0)){
        	move = 2;
    	}else if (control[2]>0 && !(control[1]>0) && !(control[0]>0) && !(control[3]>0)){
        	move = 3;
    	}else if (control[3]>0 && !(control[1]>0) && !(control[2]>0) && !(control[0]>0)){
        	move = 4;
    	}
    	
    	
    	if (control[4]>0 && !(control[5]>0) && !(control[6]>0)){
        	make = 1;
    	}else if (control[5]>0 && !(control[4]>0) && !(control[6]>0)){
        	make = 2;
    	}else if (control[6]>0 && !(control[5]>0) && !(control[4]>0)){
        	make = 3;
    	}
    	Integer[] returnArr = {move, make};
    	
    	return returnArr;
    }
    
    //only need to call this to make a move
    public static void moveMaker(HeadlessWorkspace workspace, Genome genome, float[] inputs){
    	//should probably put in a try catch
    	Integer[] moves = moveCalculator(genome, inputs);
    	if (moves[0] == 1){
    		System.out.println("up");
        	workspace.command("ask player [player-moves-up]");
    	}else if (moves[0] == 2){
    		System.out.println("down");
        	workspace.command("ask player [player-moves-down]");
    	}else if (moves[0] == 3){
    		System.out.println("left");
        	workspace.command("ask player [player-moves-left]");
    	} else if (moves[0] == 4){
    		System.out.println("right");
        	workspace.command("ask player [player-moves-right]");
    	}else{
    		//zeroCounter+=1;
    	}
    	
    	if (moves[1] == 1){
    		System.out.println("triangle");
        	workspace.command("ask player [if not any? other turtles-here[spawn-triangle player-xcor player-ycor 105 \"player\"]]");
    	} else if (moves[1] == 2){
    		System.out.println("circle");

        	workspace.command("ask player [if not any? other turtles-here[spawn-circle player-xcor player-ycor 105 \"player\"]]");
    	}else if (moves[1] == 3){
    		System.out.println("square");

        	workspace.command("ask player [if not any? other turtles-here[spawn-square player-xcor player-ycor 105 \"player\"]]");
    	}else{
    		//zeroCounter+=1;
    	}
    }
//  Placed in the Evaluator!
//    public static int winConditionCheck(HeadlessWorkspace workspace){
//    	Double x = (Double) workspace.report("count patches with [pcolor = red]");
//        Double y = (Double) workspace.report("count patches with [pcolor = blue]");
//        if (x==0){
//        	return 1;
//        }
//        if (y==0){
//        	return -1;
//        }
//		return 0;
//    	
//    }
    
    public static int winConditionCheck(HeadlessWorkspace workspace){
    	Double x = (Double) workspace.report("count patches with [pcolor = red]");
    	
        Double y = (Double) workspace.report("count patches with [pcolor = blue]");
        System.out.println("remaining blue patches : " +y.toString());
        if (x==0){
        	System.out.print("Player win");
        	return 1;
        }
        if (y==0){
        	System.out.print("System win");
        	return -1;
        }
		return 0;
    	
    }
}