package com.hydrozoa.hydroneat;

public class Counter {
	
	private int currentInnovation = 0;
	
	public int getInnovation() {
		return currentInnovation++;
	}
}
