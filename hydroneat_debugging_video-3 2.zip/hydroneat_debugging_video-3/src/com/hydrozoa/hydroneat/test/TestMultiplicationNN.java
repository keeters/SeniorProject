package com.hydrozoa.hydroneat.test;

import java.util.Random;

import com.hydrozoa.hydroneat.ConnectionGene;
import com.hydrozoa.hydroneat.Counter;
import com.hydrozoa.hydroneat.Evaluator;
import com.hydrozoa.hydroneat.Genome;
import com.hydrozoa.hydroneat.NEATConfiguration;
import com.hydrozoa.hydroneat.NeuralNetwork;
import com.hydrozoa.hydroneat.NodeGene;
import com.hydrozoa.hydroneat.NodeGene.TYPE;

public class TestMultiplicationNN {
	
	public static void main(String[] args) {
		Random random = new Random();
		
		Counter nodeInn = new Counter();
		Counter connInn = new Counter();
		
		Genome genome = new Genome();
		genome.addNodeGene(new NodeGene(TYPE.INPUT, nodeInn.getInnovation()));				// node id is 0
		genome.addNodeGene(new NodeGene(TYPE.INPUT, nodeInn.getInnovation()));				// node id is 1
		genome.addNodeGene(new NodeGene(TYPE.OUTPUT, nodeInn.getInnovation()));				// node id is 2
		genome.addConnectionGene(new ConnectionGene(0,2,1f,true, connInn.getInnovation()));	// conn id is 0
		genome.addConnectionGene(new ConnectionGene(1,2,1f,true, connInn.getInnovation()));	// conn id is 1
		
		NEATConfiguration conf = new NEATConfiguration(500);
		conf.DT=5f;
		
		Evaluator eval = new Evaluator(conf, genome, nodeInn, connInn) {
			@Override
			protected float evaluateGenome(Genome genome) {
				float totalDistance = 0f;
				for (int i = 0; i < 10; i++) {
					float input1 = random.nextFloat()*100f; // random floats between 0 and 100
					float input2 = random.nextFloat()*100f;
					
					NeuralNetwork net = new NeuralNetwork(genome);
					float[] inputs = {input1, input2};
					float[] outputs = net.calculate(inputs);
					System.out.println("outputs" + Float.toString(outputs[0]));
					if (outputs == null) {
						System.out.println("Priting failed network to output/multiplication_1/fail.png");
						LegacyGenomePrinter.printGenome(genome, "output/multiplication_1/fail.png");
						LegacyGenomePrinter.printGenomeText(genome);
						System.exit(1);
					}
					float guess = outputs[0];
					float product = input1 * input2;
					float distance = Math.abs(guess-product);
					totalDistance += distance;
				}
				if (totalDistance == 0f) {
					return 1000f;
				}
				return (1000f/totalDistance);
			}
		};
		
		for (int i = 0; i < 100; i++) {
			eval.evaluate();
			System.out.print("Generation: "+i);
			System.out.print("\tHighest fitness: "+eval.getHighestFitness());
			System.out.print("\tAmount of species: "+eval.getSpeciesAmount());
			System.out.print("\tConnections in best performer: "+eval.getFittestGenome().getConnectionGenes().values().size());
			System.out.print("\n");
			if (i%10==0) {
				LegacyGenomePrinter.printGenome(eval.getFittestGenome(), "output/multiplication_1/"+i+".png");
			}
		}
		
		NeuralNetwork net = new NeuralNetwork(genome);
		float[] input = {1f};
		float[] output = net.calculate(input);
		System.out.println("output is of length="+output.length+" and has output[0]="+output[0]+"\t expecting 0.73");
	}

}
