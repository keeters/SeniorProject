package com.hydrozoa.hydroneat.test.evaluator;

import com.hydrozoa.hydroneat.ConnectionGene;
import com.hydrozoa.hydroneat.Counter;
import com.hydrozoa.hydroneat.Evaluator;
import com.hydrozoa.hydroneat.Genome;
import com.hydrozoa.hydroneat.NEATConfiguration;
import com.hydrozoa.hydroneat.NodeGene;
import com.hydrozoa.hydroneat.NodeGene.TYPE;
import com.hydrozoa.hydroneat.test.LegacyGenomePrinter;

/**
 * Tests a simple evaluator that runs for 100 generations, and scores fitness based on how close the sum of the weights is to 100.
 * 
 * @author hydrozoa
 */
public class TestEvaluatorHundredSum {
	
	public static void main(String[] args) {
		Counter nodeInnovation = new Counter();
		Counter connectionInnovation = new Counter();
		
		Genome genome = new Genome();
		int n1 = nodeInnovation.getInnovation();
		int n2 = nodeInnovation.getInnovation();
		int n3 = nodeInnovation.getInnovation();
		genome.addNodeGene(new NodeGene(TYPE.INPUT, n1));
		genome.addNodeGene(new NodeGene(TYPE.INPUT, n2));
		genome.addNodeGene(new NodeGene(TYPE.OUTPUT, n3));
		
		int c1 = connectionInnovation.getInnovation();
		int c2 = connectionInnovation.getInnovation();
		genome.addConnectionGene(new ConnectionGene(n1,n3,0.5f,true,c1));
		genome.addConnectionGene(new ConnectionGene(n2,n3,0.5f,true,c2));
		
		NEATConfiguration conf = new NEATConfiguration(100);
		conf.DT=10f;
		
		Evaluator eval = new Evaluator(conf, genome, nodeInnovation, connectionInnovation) {
			@Override
			protected float evaluateGenome(Genome genome) {
				float weightSum = 0f;
				for (ConnectionGene cg : genome.getConnectionGenes().values()) {
					if (cg.isExpressed()) {
						weightSum += Math.abs(cg.getWeight());
					}
				}
				float difference = Math.abs(weightSum-100f);
				return (1000f/difference);
			}
		};
		
		for (int i = 0; i < 1000; i++) {
			eval.evaluate();
			System.out.print("Generation: "+i);
			System.out.print("\tHighest fitness: "+eval.getHighestFitness());
			System.out.print("\tAmount of species: "+eval.getSpeciesAmount());
			System.out.print("\tConnections in best performer: "+eval.getFittestGenome().getConnectionGenes().values().size());
			float weightSum = 0;
			for (ConnectionGene cg : eval.getFittestGenome().getConnectionGenes().values()) {
				if (cg.isExpressed()) {
					weightSum += Math.abs(cg.getWeight());
				}
			}
			System.out.print("\tWeight sum: "+weightSum);
			System.out.print("\n");
			if (i%10==0) {
				LegacyGenomePrinter.printGenome(eval.getFittestGenome(), "output/connection_sum_100/"+i+".png");
			}
		}
	}

}
